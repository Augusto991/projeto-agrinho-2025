let larguraCenario = 2000;
let deslocamentoCenario = 0;
let estacoes = [];
let jogandoMiniJogo = false;
let miniJogoAtivo = null;
let tempoInicio;
let duracaoJogo = 15000;
let jogoFinalizado = false;
let pontos = 0;
let showVitoria = false;
let showPerda = false;
let telaInicial = true;
let emoji = '👩‍🌾';
let portalAtivo = false;
let linkVitoria = '';
let posChao;

let inimigos = [];

function setup() {
  createCanvas(800, 400);
  posChao = height - 50;
  personagem = new Personagem(50, posChao - 50); 

  estacoes.push(new Estacao(400, "Agricultura Familiar", "https://pt.wikipedia.org/wiki/Agricultura_familiar"));
  estacoes.push(new Estacao(800, "Sustentabilidade", "https://pt.wikipedia.org/wiki/Sustentabilidade"));
  estacoes.push(new Estacao(1200, "Tecnologia no Campo", "https://pt.wikipedia.org/wiki/Tecnologia_agropecuária"));
}

function draw() {
  if (telaInicial) {
    mostrarTelaInicial();
    return;
  }

  background(135, 206, 235);

  if (showVitoria) {
    mostrarTelaVitoria();
    return;
  } else if (showPerda) {
    mostrarTelaPerda();
    return;
  } else if (jogandoMiniJogo) {
    exibirMiniJogo(miniJogoAtivo);
    return;
  }

  mostrarComandos();

  let cameraX = constrain(personagem.pos.x - width / 2, 0, larguraCenario - width);
  deslocamentoCenario = -cameraX;

  push();
  translate(deslocamentoCenario, 0);

  // Chão
  fill(34, 139, 34);
  rect(0, posChao - 20, larguraCenario, 20);
  fill(139, 69, 19);
  rect(0, posChao, larguraCenario, height - posChao);

  for (let est of estacoes) {
    est.exibir();
    est.checarProximidade(personagem.pos.x);
  }

  if (portalAtivo && dist(personagem.pos.x, personagem.pos.y, estacoes[estacoes.length - 1].x, posChao) < 80) {
    mostrarPortal();
  }

  personagem.atualizar();
  personagem.exibir();
  pop();
}

function mostrarTelaInicial() {
  background(255);
  fill(0);
  textAlign(CENTER, CENTER);
  textSize(24);
  text("Bem-vindo ao Jogo Educacional!", width / 2, 50);
  textSize(16);
  text("Explore os temas abaixo interagindo com os portais no mapa.", width / 2, 90);
  text("Pressione qualquer tecla para começar.", width / 2, height - 40);

  textSize(14);
  text("🌾 Agricultura Familiar", width / 2, 140);
  text("https://pt.wikipedia.org/wiki/Agricultura_familiar", width / 2, 160);

  text("♻️ Sustentabilidade", width / 2, 200);
  text("https://pt.wikipedia.org/wiki/Sustentabilidade", width / 2, 220);

  text("🚁 Tecnologia no Campo", width / 2, 260);
  text("https://pt.wikipedia.org/wiki/Tecnologia_agropecuária", width / 2, 280);
}

function keyPressed() {
  if (telaInicial) {
    telaInicial = false;
    return;
  }

  if ((key === 'Y' || keyCode === ENTER) && !jogandoMiniJogo) {
    for (let est of estacoes) {
      if (abs(personagem.pos.x - est.x) < 80) {
        jogandoMiniJogo = true;
        miniJogoAtivo = est.titulo;
        tempoInicio = millis();
        pontos = 0;
        jogoFinalizado = false;
        linkVitoria = est.link || '';
        if (miniJogoAtivo === "Tecnologia no Campo") {
          iniciarJogoTecnologia();
        }
      }
    }
  }

  if (keyCode === ESCAPE) {
    showVitoria = false;
    showPerda = false;
    jogandoMiniJogo = false;
    miniJogoAtivo = null;
    inimigos = [];
  }

  if (key === 'F' && showPerda) {
    showPerda = false;
    jogandoMiniJogo = true;
    tempoInicio = millis();
    pontos = 0;
    jogoFinalizado = false;
    if (miniJogoAtivo === "Tecnologia no Campo") {
      iniciarJogoTecnologia();
    }
  }

  // Ação para ganhar pontos
  if (jogandoMiniJogo && !jogoFinalizado && (key === ' ' || key === 'Z')) {
    if (miniJogoAtivo === "Agricultura Familiar") pontos += 50;
    if (miniJogoAtivo === "Sustentabilidade") pontos += 50;
  }
}

function mostrarComandos() {
  fill(255);
  stroke(0);
  rect(10, 10, 250, 90, 10);
  noStroke();
  fill(0);
  textSize(12);
  textAlign(LEFT);
  text("Comandos:", 20, 30);
  text("A / D: mover", 20, 45);
  text("Y / Enter: interagir", 20, 60);
  text("ESC: sair do mini-jogo", 20, 75);
  if (showPerda) {
    text("F: tentar novamente", 20, 90);
  }
}

function exibirMiniJogo(nome) {
  if (nome === "Agricultura Familiar") {
    background(255, 170, 0); // Céu
    fill(204, 119, 34);
    rect(0, height / 2, width, height / 2);
    fill(0);
    textAlign(CENTER);
    textSize(18);
    text("Plante pressionando espaço! 🌾", width / 2, 30);
    text("Pontos: " + pontos, width / 2, 60);
    if (!jogoFinalizado && millis() - tempoInicio > duracaoJogo) {
      showVitoria = pontos >= 1000;
      showPerda = !showVitoria;
      jogoFinalizado = true;
    }

  } else if (nome === "Sustentabilidade") {
    background(135, 206, 235);
    fill(34, 139, 34);
    rect(0, posChao - 20, width, 20);
    fill(139, 69, 19);
    rect(0, posChao, width, height - posChao);
    fill(0);
    textAlign(CENTER);
    textSize(18);
    text("Colete lixo pressionando espaço! 🗑️", width / 2, 30);
    text("Pontos: " + pontos, width / 2, 60);
    if (!jogoFinalizado && millis() - tempoInicio > duracaoJogo) {
      showVitoria = pontos >= 2000;
      showPerda = !showVitoria;
      jogoFinalizado = true;
    }

  } else if (nome === "Tecnologia no Campo") {
    background(0);
    fill(255);
    textAlign(LEFT);
    textSize(18);
    text("Tecnologia no Campo", 20, 30);
    text("Pontos: " + pontos, 20, 60);

    personagemTecnologia();
    atualizarInimigos();
    exibirInimigos();

    if (inimigos.every(i => !i.vivo) && !jogoFinalizado) {
      showVitoria = true;
      jogoFinalizado = true;
    }
  }
}

function mostrarTelaVitoria() {
  background(0, 255, 0);
  fill(0);
  textAlign(CENTER, CENTER);
  textSize(32);
  text("Você ganhou!", width / 2, height / 2 - 50);
  textSize(18);
  text("Tema: " + miniJogoAtivo, width / 2, height / 2 + 10);
  if (linkVitoria) {
    fill(0, 0, 255);
    textSize(14);
    text("Leia mais: " + linkVitoria, width / 2, height / 2 + 40);
  }
  fill(0);
  text("Pressione ESC para voltar ao mapa", width / 2, height / 2 + 70);
}

function mostrarTelaPerda() {
  background(255, 0, 0);
  fill(255);
  textAlign(CENTER, CENTER);
  textSize(32);
  text("Você perdeu!", width / 2, height / 2 - 50);
  textSize(18);
  text("Pressione 'F' para tentar novamente", width / 2, height / 2 + 10);
}

function mostrarPortal() {
  fill(255, 215, 0);
  textAlign(CENTER, CENTER);
  textSize(40);
  text("Portal Final!", width / 2, height / 2);
  textSize(20);
  text("Feito por Augusto C. S. Manzi", width / 2, height / 2 + 40);
  text("Sob orientação do Prof. Daniel Alvez", width /2, height / 2 + 60);
  text("Pressione Enter para entrar", width / 2, height / 2 + 80);
}

class Personagem {
  constructor(x, y) {
    this.pos = createVector(x, y);
    this.vel = createVector(0, 0);
    this.acc = createVector(0, 0);
    this.altura = 70;
    this.largura = 40;
    this.velocidade = 3;
    this.noChao = true;
  }

  atualizar() {
    this.movimento();
    this.gravidade();
    this.colisaoChao();
    this.pos.add(this.vel);
  }

  movimento() {
    this.acc.x = 0;
    if (keyIsDown(65)) this.acc.x = -this.velocidade;
    if (keyIsDown(68)) this.acc.x = this.velocidade;
    this.vel.x = this.acc.x;
  }

  gravidade() {
    this.acc.y = this.noChao ? 0 : 0.8;
    this.vel.y += this.acc.y;
  }

  colisaoChao() {
    if (this.pos.y + this.altura / 2 >= posChao) {
      this.pos.y = posChao - this.altura / 2;
      this.vel.y = 0;
      this.noChao = true;
    } else {
      this.noChao = false;
    }
  }

  exibir() {
    textSize(32);
    textAlign(CENTER, CENTER);
    text(emoji, this.pos.x, this.pos.y);
  }
}

class Estacao {
  constructor(x, titulo, link) {
    this.x = x;
    this.titulo = titulo;
    this.link = link;
  }

  exibir() {
    fill(200, 100, 100);
    rect(this.x, posChao - 50, 60, 50);
    fill(255);
    textAlign(CENTER, CENTER);
    textSize(10);
    text(this.titulo, this.x + 30, posChao - 70);
  }

  checarProximidade(px) {
    if (abs(px - this.x) < 80) {
      fill(255);
      textAlign(CENTER);
      textSize(12);
      text("Pressione Y ou Enter para entrar", this.x + 30, posChao - 80);
      portalAtivo = true;
    }
  }
}

function iniciarJogoTecnologia() {
  inimigos = [];
  for (let i = 0; i < 5; i++) {
    inimigos.push({
      x: random(width * 0.5, width - 50),
      y: random(100, height - 100),
      pontuacao: floor(random(50, 150)),
      tamanho: 30,
      vivo: true,
    });
  }
  pontos = 0;
}

function personagemTecnologia() {
  fill(0, 255, 0);
  rect(width / 2 - 15, height - 60, 30, 30);
  if (keyIsDown(32)) {
    for (let inimigo of inimigos) {
      if (inimigo.vivo && dist(width / 2, height - 60, inimigo.x, inimigo.y) < 50) {
        inimigo.vivo = false;
        pontos += inimigo.pontuacao;
      }
    }
  }
}

function atualizarInimigos() {
  for (let inimigo of inimigos) {
    if (inimigo.vivo) {
      inimigo.x -= 1;
      if (inimigo.x < 0) inimigo.x = width;
    }
  }
}

function exibirInimigos() {
  fill(255, 0, 0);
  for (let inimigo of inimigos) {
    if (inimigo.vivo) {
      ellipse(inimigo.x, inimigo.y, inimigo.tamanho);
    }
  }
}
